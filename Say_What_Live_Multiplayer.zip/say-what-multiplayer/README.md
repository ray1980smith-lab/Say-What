# Say What?! – Live Multiplayer

A mobile-first, real-time sound-alike guessing game for 2–10 people, all using their own Android or iPhone. Includes 166 original puzzles, room-code invitations, instant answer checking, a shared countdown, hints, fastest-correct bonuses, and live rankings.

## Start locally (computer)

Requires Node.js 20 or newer. No external npm packages required.

```bash
npm start
```

Open http://localhost:3000. Other devices on the same Wi-Fi can open `http://YOUR-COMPUTER-LAN-IP:3000` if your firewall allows port 3000.

## Get a public link to share with friends

Upload this project to a GitHub repository and deploy as a **web service** on a Node hosting provider such as Railway or Render. Set the start command to `npm start`, and keep **one running instance**. The app automatically listens on the provider's `PORT` variable. A Dockerfile is included for Docker-friendly hosts.

Once deployed, open the public HTTPS address on any phone, create a room and tap **Share invite**. Friends join from the link or by typing a 6-character room code. Players do **not** need to install anything.

### Important limitations

- The app **cannot connect different phones through an offline HTML file alone**. To play over the internet it must run on a reachable server.
- Rooms and scores live only in server memory. Restarting or redeploying the service resets active rooms; expired rooms are removed after about four hours of inactivity.
- Run a **single server instance** with no autoscaling; separate instances would not share room state. A persistent database/pub-sub would be needed for a larger production deployment.
- Hosting fees and free tiers vary by provider. Verify the current pricing and sleep restrictions before deploying.
- The host chooses category, difficulty, round count and timer before creating the room. In-game scoring: 2 points per correct guess, 1 point if a hint is used, plus 1 bonus point for the fastest correct answer.
- This casual game is not an anti-cheat tournament platform. Room-code privacy is lightweight; do not use it for money games or sensitive information.

## Tests

```bash
npm test
```
