'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, randomInt, timingSafeEqual } = require('node:crypto');
const CARDS = require('./cards.json');
const PORT = Number(process.env.PORT || 3000);
const rooms = new Map();
const ROOM_LIFETIME = 4 * 60 * 60 * 1000;
const MAX_PLAYERS = 10;
const VALID_CATS = [...new Set(CARDS.map(c => c.cat))];
const charset = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const html = fs.readFileSync(path.join(__dirname,'public','index.html'));
const log = (...a) => console.log(new Date().toISOString(), ...a);
const makeToken = () => randomBytes(24).toString('base64url');
const makeCode = () => Array.from({length:6},()=>charset[randomInt(charset.length)]).join('');
const safeName = name => String(name || '').trim().replace(/[<>\x00-\x1f]/g,'').slice(0,24);
const safeCode = code => String(code || '').toUpperCase().replace(/[^A-Z2-9]/g,'').slice(0,6);
const norm = text => String(text || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/&/g,'and').replace(/[^a-z0-9]/g,'');
const editDistance = (a,b) => {
 if (Math.abs(a.length-b.length)>2) return 3;
 let prev=Array.from({length:b.length+1},(_,i)=>i);
 for(let i=1;i<=a.length;i++) {const curr=[i]; for(let j=1;j<=b.length;j++) curr[j]=Math.min(curr[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1)); prev=curr;} return prev[b.length];
};
const validAnswer = (guess, answer) => {const g=norm(guess), a=norm(answer); return !!g && (g===a || (a.length>=10 && editDistance(g,a)<=1));};
function getRoom(code){ const r=rooms.get(safeCode(code)); if(!r)return null; if(Date.now()-r.lastActivity>ROOM_LIFETIME) {destroyRoom(r);return null;} return r; }
function playerFor(r, token){return r.players.find(p=>p.token===token) || null;}
function getConfig(src){const time=[30,60,90].includes(+src.time)?+src.time:60; const rounds=[5,10,15].includes(+src.rounds)?+src.rounds:10; const level=[0,1,2,3].includes(+src.level)?+src.level:0;const cat=VALID_CATS.includes(src.cat)?src.cat:'All';return {time,rounds,level,cat};}
function newRoom(name, config){let code;do{code=makeCode();}while(rooms.has(code));const token=makeToken();const now=Date.now();const p={id:makeToken().slice(0,12),token,name,score:0,hint:false,guess:null,correctAt:null,misses:0,ready:false};const r={code,hostId:p.id,players:[p],stage:'lobby',config,round:0,current:null,picked:new Set(),startedAt:0,endsAt:0,roundId:0,lastActivity:now,events:new Set(),timeout:null};rooms.set(code,r);return {r,p};}
function selectCard(r){let pool=CARDS.filter(c=>(r.config.level===0||c.level===r.config.level)&&(r.config.cat==='All'||c.cat===r.config.cat));let unused=pool.map((card,i)=>i).filter(i=>!r.picked.has(pool[i].g));if(!unused.length){r.picked.clear();unused=pool.map((c,i)=>i);}const card=pool[unused[randomInt(unused.length)]];r.picked.add(card.g);return card;}
function snapshot(r,p){checkExpiry(r);const ended=r.stage==='results'||r.stage==='finished';return {code:r.code,stage:r.stage,host:p.id===r.hostId,me:{id:p.id,name:p.name,score:p.score,hint:p.hint,guess:p.guess,correct:p.correctAt!==null,misses:p.misses},players:r.players.map(q=>({id:q.id,name:q.name,score:q.score,submitted:q.correctAt!==null,attempted:q.misses>0,ready:q.ready})).sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name)),hostId:r.hostId,config:r.config,round:r.round,maxPlayers:MAX_PLAYERS,roundId:r.roundId,serverNow:Date.now(),endsAt:r.endsAt,card:r.current?{g:r.current.g,cat:r.current.cat,level:r.current.level,...(p.hint||ended?{hint:r.current.h}:{}) ,...(ended?{answer:r.current.a}:{})}:null,results:ended?r.results||[]:[],isFinal:r.stage==='finished'};}
function checkExpiry(r){if(r.stage==='playing' && Date.now()>=r.endsAt) finishRound(r);}
function finishRound(r){if(r.stage!=='playing')return;if(r.timeout){clearTimeout(r.timeout);r.timeout=null;}const winners=r.players.filter(p=>p.correctAt!==null).sort((a,b)=>a.correctAt-b.correctAt);const first=winners.length?winners[0].id:null;for(const p of winners){p.score+=(p.hint?1:2)+(p.id===first?1:0);}r.results=r.players.map(p=>({id:p.id,name:p.name,correct:p.correctAt!==null,guess:p.guess,hint:p.hint,points:p.correctAt===null?0:(p.hint?1:2)+(p.id===first?1:0),first:p.id===first})).sort((a,b)=>b.points-a.points||a.name.localeCompare(b.name));r.stage=(r.round>=r.config.rounds?'finished':'results');broadcast(r);}
function startRound(r){if(r.stage!=='lobby'&&r.stage!=='results')throw new Error('Round cannot start yet');if(r.stage==='lobby'&&r.players.length<2)throw new Error('At least two players are needed');r.round++;r.roundId++;r.current=selectCard(r);r.stage='playing';r.startedAt=Date.now();r.endsAt=r.startedAt+r.config.time*1000;r.results=[];for(const p of r.players){p.hint=false;p.guess=null;p.correctAt=null;p.misses=0;}r.timeout=setTimeout(()=>finishRound(r),r.config.time*1000+20);broadcast(r);}
function broadcast(r){for(const client of [...r.events]) {try{client.res.write('event: state\ndata: '+JSON.stringify(snapshot(r,client.p))+'\n\n');}catch{r.events.delete(client);}}}
function destroyRoom(r){if(r.timeout)clearTimeout(r.timeout);for(const client of r.events){try{client.res.end();}catch{}}rooms.delete(r.code);}
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
async function bodyJson(req){return await new Promise((resolve,reject)=>{let data='';req.on('data',chunk=>{data+=chunk;if(data.length>12000){reject(new Error('Request too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(data||'{}'));}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);});}
function auth(obj){const r=getRoom(obj.code);if(!r)throw new Error('Room not found or expired');const p=playerFor(r,obj.token);if(!p)throw new Error('Player session missing. Join again.');r.lastActivity=Date.now();return {r,p};}
function action(r,p,a){checkExpiry(r);switch(a.type){
 case 'start':case 'next':if(p.id!==r.hostId)throw new Error('Only the host can start rounds');startRound(r);return;
 case 'hint':if(r.stage!=='playing'||!r.current)throw new Error('This round has finished');p.hint=true;broadcast(r);return;
 case 'guess':if(r.stage!=='playing')throw new Error('Time is up');if(p.correctAt!==null)throw new Error('You already got it right');if(typeof a.guess!=='string'||a.guess.trim().length<1||a.guess.length>100)throw new Error('Enter an answer (100 characters maximum)');if(p.misses>=10)throw new Error('Maximum guesses reached this round');p.misses++;p.guess=a.guess.trim().slice(0,100);if(validAnswer(p.guess,r.current.a))p.correctAt=Date.now();broadcast(r);return;
 case 'finish':if(p.id!==r.hostId)throw new Error('Only the host can end a game');if(r.stage==='playing')finishRound(r);r.stage='finished';broadcast(r);return;
 case 'restart':if(p.id!==r.hostId)throw new Error('Only the host can restart');if(r.timeout)clearTimeout(r.timeout);r.stage='lobby';r.round=0;r.current=null;r.results=[];r.picked.clear();r.roundId++;for(const q of r.players){q.score=0;q.guess=null;q.correctAt=null;q.hint=false;q.misses=0;}broadcast(r);return;
 case 'leave':r.players=r.players.filter(q=>q.id!==p.id);if(!r.players.length)destroyRoom(r);else {if(r.hostId===p.id)r.hostId=r.players[0].id;broadcast(r);}return;
 default:throw new Error('Unknown action');}
}
const server=http.createServer(async(req,res)=>{try{const u=new URL(req.url,'http://localhost');if(req.method==='GET' && (u.pathname==='/'||u.pathname==='/index.html')) {res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(html);return;}
 if(req.method==='GET'&&u.pathname==='/health'){send(res,200,{ok:true,rooms:rooms.size,cards:CARDS.length});return;}
 if(req.method==='POST'&&u.pathname==='/api/create'){const d=await bodyJson(req),name=safeName(d.name);if(!name)throw new Error('Enter your name');if(rooms.size>=100)throw new Error('Too many rooms, try later');const {r,p}=newRoom(name,getConfig(d.config||{}));send(res,200,{code:r.code,token:p.token,state:snapshot(r,p)});return;}
 if(req.method==='POST'&&u.pathname==='/api/join'){const d=await bodyJson(req),r=getRoom(d.code),name=safeName(d.name);if(!r)throw new Error('That room code was not found');if(!name)throw new Error('Enter your name');if(r.stage==='finished')throw new Error('Game has finished — ask the host to restart');if(r.players.length>=MAX_PLAYERS)throw new Error('Room is full');if(r.players.some(p=>p.name.toLowerCase()===name.toLowerCase()))throw new Error('That name is already taken');const p={id:makeToken().slice(0,12),token:makeToken(),name,score:0,hint:false,guess:null,correctAt:null,misses:0,ready:false};r.players.push(p);r.lastActivity=Date.now();send(res,200,{code:r.code,token:p.token,state:snapshot(r,p)});broadcast(r);return;}
 if(req.method==='GET'&&u.pathname==='/api/state'){const {r,p}=auth({code:u.searchParams.get('code'),token:u.searchParams.get('token')});send(res,200,{state:snapshot(r,p)});return;}
 if(req.method==='GET'&&u.pathname==='/api/events'){const {r,p}=auth({code:u.searchParams.get('code'),token:u.searchParams.get('token')});res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});const client={res,p};r.events.add(client);res.write('retry: 2000\n\nevent: state\ndata: '+JSON.stringify(snapshot(r,p))+'\n\n');const pulse=setInterval(()=>{try{res.write(': ping\n\n');checkExpiry(r);}catch{}},15000);req.on('close',()=>{clearInterval(pulse);r.events.delete(client);});return;}
 if(req.method==='POST'&&u.pathname==='/api/action'){const d=await bodyJson(req),{r,p}=auth(d);action(r,p,d);send(res,200,{state:rooms.has(r.code)?snapshot(r,p):null});return;}
 send(res,404,{error:'Not found'});
 }catch(err){send(res,400,{error:err.message||'Unexpected error'});}});
setInterval(()=>{for(const r of rooms.values()){checkExpiry(r);if(Date.now()-r.lastActivity>ROOM_LIFETIME)destroyRoom(r);}},60000).unref();
server.listen(PORT,'0.0.0.0',()=>log(`Say What?! multiplayer ready on port ${PORT} (${CARDS.length} cards)`));
module.exports={server,rooms,validAnswer,finishRound,action};
